![Sem Título-1](https://github.com/M3ndezz/Desafio-Criando-um-sistema-bancario-com-Python/assets/121885868/5211eb34-69f0-4e78-a640-255f69a0d346)
# 🏦 SISTEMA BANCÁRIO COM PYTHON 

## Desafio:

Desenvolver o novo sistema bancário, para isso escolhemos o python 3, a sua principal operação que deve ter é:

   • Depósito
   
   • Saque
   
   • Extrato

## Funcionamento:

### Operação depósito: 
Esse projeto deve trabalhar com 1 usuário, não precisa fazer identificação, todos os depósito devem ser armazenados em uma variável e ser exibido no extrato.

### Operação Saque:
O sistema deve permitir realizar 3 saques diários com o limite máximo de R$ 500,00 por saque, caso o usuário não tenha saldo, o sistema deverá exibir uma mensagem informando que não é possivel sacar o dinheiro, todos os saques devem ser armazenados em uma variável e exibidos na operação de extrato

### Operação Extrato: 
Essa operação deve listar todos os depósitos e saques realizados na conta, no fim deve ser exibido o saldo atual da conta, se o extrato tiver em branco, exibir a mensagem: Não foram realizadas movimentações.
